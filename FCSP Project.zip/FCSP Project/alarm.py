import SimpleGUICS2Pygame.simpleguics2pygame as simplegui
from time import strftime

alarm_time = "00:00"
alarm_active = False
alarm_sound=simplegui._load_local_sound('timersound.wav')

def set_alarm(text):
    global alarm_time
    alarm_time = input(text)

def start_alarm():
    global alarm_active
    alarm_active = True
    alarm_timer.start()

def stop_alarm():
    global alarm_active
    alarm_active = False
    alarm_timer.stop()
    alarm_sound.pause()

def alarm_tick():
    global alarm_active
    current_time = strftime("%H:%M")
    if alarm_active == True and current_time == alarm_time :
        alarm_sound.play()

frame = simplegui.create_frame("Alarm", 300, 200)
frame.add_input("Set Alarm (HH:MM)", set_alarm, 100)
frame.add_button("Start Alarm", start_alarm)
frame.add_button("Stop Alarm", stop_alarm)
alarm_timer = simplegui.create_timer(1000, alarm_tick)
frame.start()