import SimpleGUICS2Pygame.simpleguics2pygame as simplegui
#global :-
timer_hour = 0
timer_minutes = 0
timer_seconds = 0
time_for_timer = 0                                          #For Time
timer_on_off = False
is_clickable = True
sound = simplegui._load_local_sound('timersound.wav')
p_sound = False
def mouse_handler(pos):
    global timer_hour,timer_minutes,timer_seconds,timer_on_off
    clicked_pos = list(pos)                 
    if is_clickable :
# decrement the timer :-
        if clicked_pos[0] > 66 and clicked_pos[0] < 168:
            if clicked_pos[1] > 49 and clicked_pos[1] < 121:
                if timer_hour == 0:
                        timer_hour = 12
                else:
                        timer_hour -= 1
        if clicked_pos[0] > 200 and clicked_pos[0] < 302:
            if clicked_pos[1] > 49 and clicked_pos[1] < 121:
                if timer_minutes == 0:
                        timer_minutes = 59
                else:
                        timer_minutes -= 1
        if clicked_pos[0] > 334 and clicked_pos[0] < 436:
            if clicked_pos[1] > 49 and clicked_pos[1] < 121:
                if timer_seconds == 0:
                        timer_seconds = 59
                else:
                        timer_seconds -= 1
# increment the timer :-
        if clicked_pos[0] > 66 and clicked_pos[0] < 168:
            if clicked_pos[1] > 219 and clicked_pos[1] < 291:
                if timer_hour == 12:
                        timer_hour = 0
                else:
                        timer_hour += 1
        if clicked_pos[0] > 200 and clicked_pos[0] < 302:
            if clicked_pos[1] > 219 and clicked_pos[1] < 291:
                if timer_minutes == 59:
                        timer_minutes = 0
                else:
                        timer_minutes += 1
        if clicked_pos[0] > 334 and clicked_pos[0] < 436:
            if clicked_pos[1] > 219 and clicked_pos[1] < 291:
                if timer_seconds == 59:
                        timer_seconds = 0
                else:
                        timer_seconds += 1
        if clicked_pos[0] > 200 and clicked_pos[0] < 312:               #start timer
            if clicked_pos[1] > 399 and clicked_pos[1] < 451:
                    start_timer()
                    timer_on_off = True
        if clicked_pos[0] > 109 and clicked_pos[0] < 231:               #cancel timer
            if clicked_pos[1] > 399 and clicked_pos[1] < 451:
                    stop_timer()
                    timer_on_off = False
                    timer_mode()
        if clicked_pos[0] > 279 and clicked_pos[0] < 391:               #pause timer
            if clicked_pos[1] > 399 and clicked_pos[1] < 451:
                    timer_on_off = True
                    if timer.is_running():
                        stop_timer()
                    else:
                        start_timer()
def timer_control():
    global timer_hour,timer_minutes,timer_seconds
    if timer_seconds == 0:
        if timer_minutes == 0:
            if timer_hour != 0:
                timer_hour -= 1
                timer_minutes = 59
                timer_seconds = 59
        else:
            timer_minutes -= 1
            timer_seconds = 59
    else:
        timer_seconds -= 1
    if timer_hour == 0 and timer_minutes == 0 and timer_seconds == 0:
        global is_clickable
        stop_timer()
        play_sound()
        is_clickable = True
def start_timer():
    global p_sound 
    p_sound = False
    is_clickable = False
    timer.start()
def pause_resume_timer():
    if timer.is_running():
        stop_timer()
    else:
        start_timer()
def stop_timer():
    timer.stop()
def play_sound():
    global p_sound 
    p_sound = not p_sound
    sound.play()
    timer_mode()
def timer_mode():                                                       #For On / Off Timer
    global timer_hour,timer_minutes,timer_seconds,p_sound,timer_on_off,time_for_timer,is_clickable
    timer_on_off = False
    p_sound = False
    frame.set_mouseclick_handler(mouse_handler)
    timer_hour = 0
    timer_minutes = 0
    timer_seconds = 0
    time_for_timer = 0
    is_clickable = True
def draw(canvas):                                                           # To display timer
        canvas.draw_polyline([(117,55),(77,110),(157,110),(117,55)],5,'white')
        canvas.draw_polyline([(251,55),(211,110),(291,110),(251,55)],5,'white')
        canvas.draw_polyline([(385,55),(345,110),(425,110),(385,55)],5,'white')
        canvas.draw_polygon([(67,50),(167,50),(167,120),(67,120)],5,'red')
        canvas.draw_polygon([(201,50),(301,50),(301,120),(201,120)],5,'red')
        canvas.draw_polygon([(335,50),(435,50),(435,120),(335,120)],5,'red')
        if timer_hour < 10:
            canvas.draw_text('0'+str(timer_hour),(70,200),100,'blue')
        else:
            canvas.draw_text(str(timer_hour),(70,200),100,'blue')
        if timer_minutes < 10:
            canvas.draw_text('0'+str(timer_minutes),(205,200),100,'blue')
        else:
            canvas.draw_text(str(timer_minutes),(205,200),100,'blue')
        if timer_seconds < 10:
            canvas.draw_text('0'+str(timer_seconds),(340,200),100,'blue')
        else:
            canvas.draw_text(str(timer_seconds),(340,200),100,'blue')
        canvas.draw_polyline([(77,228),(157,228),(117,285),(77,228)],5,'white')
        canvas.draw_polyline([(211,228),(291,228),(251,285),(211,228)],5,'white')
        canvas.draw_polyline([(345,228),(425,228),(385,285),(345,228)],5,'white')
        canvas.draw_polygon([(67,220),(167,220),(167,290),(67,290)],5,'red')
        canvas.draw_polygon([(201,220),(301,220),(301,290),(201,290)],5,'red')
        canvas.draw_polygon([(335,220),(435,220),(435,290),(335,290)],5,'red')
        if timer_on_off:                                                       #to display the button for on/off mode of timer
            canvas.draw_polygon([(110,400),(230,400),(230,450),(110,450)],5,'red')
            canvas.draw_text('Cancel',(117,438),38,'white')                    #cancle timer
            canvas.draw_polygon([(280,400),(390,400),(390,450),(280,450)],5,'red')
            canvas.draw_text('Pause',(287,438),40,'white')                     #pause timer
        else:
            canvas.draw_polygon([(201,400),(311,400),(311,450),(201,450)],5,'red')
            canvas.draw_text('Start',(207,438),50,'white')                     #start timer
frame = simplegui.create_frame('Timer',500,500)
timer = simplegui.create_timer(1000,timer_control)
frame.set_draw_handler(draw)
frame.add_button('Timer',timer_mode)
frame.start()
